import { ethers } from 'ethers';

const token_contract_adress = "0x5FbDB2315678afecb367f032d93F642f64180aa3";
const token_abi = [
    {
     "inputs": [
        {
          "internalType": "address",
          "name": "initialOwner",
          "type": "address"
        }
    ]
    }
];

let provider;
let signer;
let userAdress;
let contract;

async function connectWallet() {
    const provider= new ethers.BrowserProvider(window.ethereum);
    const accounts= await provider.send('eth_requestAccounts', []);
    userAdress= accounts[0];

    contract= new ethers.Contract(token_contract_adress, token_abi, signer);
    const shortAddr= userAdress.slice(0, 6) + "..." +userAdress.slice(-4);
    document.getElementById("walletAdress").textContent= shortAddr;

    const network= await provider.getNetwork();
    document.getElementById("network").textContent= network.name;

    const balance= await provider.getBalance(userAdress);
    const ethBalance= ethers.formatEther(balance);
    document.getElementById("ethBalance").textContent= parseFloat(ethBalance).toFixed(4) + "ETH";
    showStatus("Wallet connected");
}

async function createCampaign() {
    const title= document.getElementById("campaignTitle");
    const goal= document.getElementById("campaignGoal");
    const duration= document.getElementById("campaignDuration");

    if (!title || !goal || !duration) {
        alert("Fill the fields");
        return;
    }

    try {
        const goalWei= ethers.parseEther(goal);
        const tx= await contract.createCampaign(title, goalWei, duration);
        await tx.wait();

        document.getElementById("campaignTitle").value= "";
        document.getElementById("campaignGoal").value= "";
        document.getElementById("campaignDuration").value= "";
        showStatus("Campaign created");
    } catch(error) {
        showStatus("Error"+ error.message);
    }
}

async function loadCampaign() {
    try {
        const campaigns= await contract.getAllCampaigns();
        const listDiv= document.getElementById("campaignList");

        if (campaigns.list === 0) {
            listDiv.innerHTML= "<p>There is no campaigns</p>";
            return;
        }

        let html= "";
        for (let i= 0; i < campaigns.length; i++) {
            const camp= campaigns[i];
            const goalETH= ethers.formatEther(camp.goal);
            const raisedETH= ethers.formatEther(camp.raised);

            html += 
            <div>
                ${camp.title}
                ${goalETH}
                ${raisedETH}
                ${camp.id}
            </div>;
        }

        listDiv.innerHTML= html;
    } catch(error) {
        showStatus("Error"+ error.message);
    }
}

async function contributeCampaign() {
    const campaignID= document.getElementById("contributeCampaignID");
    const amount= document.getElementById("contributeCampaignAmount");

    if (!campaignID || !amount) {
        alert("Fill the fields");
        return;
    }

    try {
        const amountWei= ethers.parseEther(amount);
        const tx= await contract.donate(campaignID, {value: amountWei});
        await tx.wait();

        document.getElementById("contributeCampaignID").value= "";
        document.getElementById("contributeCampaignAmoount").value= "";
    } catch(error) {
        showStatus("Error"+ error.message);
    }
}

async function getCampaignInfo() {
    try {
        const count= await contract.getCampaignsCount();
        document.getElementById("totalCampaigns").textContent= count;
    } catch(error) {
        showStatus("Error"+ error.message);
    }
}

function showStatus(message) {
    const statusDiv= document.getElementById("transactionStatus");
    const div= document.createElement("div");

    statusDiv.prepend(div);

    while(statusDiv.children.length > 5) {
        statusDiv.removeChild(statusDiv.lastChild);
    }
}


